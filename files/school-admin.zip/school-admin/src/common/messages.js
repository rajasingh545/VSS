'use strict';

//Success Messages
export const REGISTER_SUCCESS = "Registered successfully";
export const SUSPENDED_SUCCESS = "Suspended successfully";

//Error Messages
export const NO_DATA = "No Data Found";
export const ORM_ERROR = "TypeORM query error:";
export const INVALID_REQUEST = "Invalid request";
export const ERROR_500 = "Something went wrong. Please try again";