import students from "../entity/students";
import {getManager} from "typeorm";
import * as MSG from "../common/messages";


export default class studentsContlr {
    constructor() {
        // this.name = name;
    }

     async registerStudents(request, response) {
        try {
            const postDataObj = request.body;
            
            if(typeof postDataObj === "object" && request.method === "POST" && postDataObj.teacher){        
                
                let studentInsertData = [];
                //when multiple students
                if(typeof postDataObj.students === "object"){
                    postDataObj.students.map((studentId)=>{
                        studentInsertData.push({
                            teacher_id: postDataObj.teacher,
                            student_id: studentId,
                            status: 1
                        }); 
                    });
                }else{ 
                    //single student
                    studentInsertData.push({           
                        teacher_id: postDataObj.teacher,
                        student_id: postDataObj.students,
                        status: 1
                    });
                }        
                const studentRepository = getManager().getRepository(students);
                const studentInserts = studentRepository.create(studentInsertData);
                await studentRepository.save(studentInserts) 
                .then(student => {               
                    this.sendResponse(response, 200, MSG.REGISTER_SUCCESS);
                }).catch(error =>{
                    // console.log(MSG.ORM_ERROR, error);
                    this.sendResponse(response, 500, MSG.ERROR_500);
                });            
            }
            else{//invalid request
                this.sendResponse(response, 400, MSG.INVALID_REQUEST);
            }
        } catch (error) {//something wrong
            this.sendResponse(response, 500, MSG.ERROR_500);
        }
    }

    async getStudents(request, response) {
        try {
            const getParams = request.query;
            
            if(typeof getParams === "object" && request.method === "GET" && getParams.teacher){

                await getManager().getRepository(students)
                .createQueryBuilder()
                .select("student_id")
                .where("teacher_id IN(:ids)", {ids : getParams.teacher}) //for the case of multiple teachers 
                .andWhere("suspended = 0 ")   // suspended = false
                .getRawMany()
                .then((studentsList)=>{
                    let students = studentsList.map(item => item.student_id);
                    let message = (students && students.length>0) ? null : MSG.NO_DATA;             
                    this.sendResponse(response, 200, message, students);
                }).catch(error => {
                    // console.log(MSG.ORM_ERROR, error);
                    this.sendResponse(response, 500, MSG.ERROR_500);
                });      

            }else{ //invalid request
                this.sendResponse(response, 400, MSG.INVALID_REQUEST);
            }
        } catch (error) {//something wrong
        this.sendResponse(response, 500, MSG.ERROR_500);
        }
    }

    async suspendStudent(request, response) {
        try {
            const getParams = request.body;
            
            if(typeof getParams === "object" && request.method === "POST" && getParams.student){

                await getManager().getRepository(students)             
                .createQueryBuilder()
                .update(students)
                .set({ suspended: true })
                .where("student_id = :id", {id:getParams.student})
                .execute()
                .then((updated)=>{ //on success            
                    this.sendResponse(response, 200, MSG.SUSPENDED_SUCCESS);
                }).catch(error => { //on query error
                    // console.log(MSG.ORM_ERROR, error);
                    this.sendResponse(response, 500, MSG.ERROR_500);
                });      

            }else{ //invalid request
                this.sendResponse(response, 400, MSG.INVALID_REQUEST);
            }
        } catch (error) {//something wrong
            this.sendResponse(response, 500, MSG.ERROR_500);
        }
    }

    async retrieveForNotifications(request, response) {
        try {
            const getParams = request.body;
            
            if(typeof getParams === "object" && getParams.teacher){

                await getManager().getRepository(students)
                .createQueryBuilder()
                .select("student_id")
                .where("teacher_id = :id ", {id : getParams.teacher}) 
                .andWhere("notification = 1 ")  //subscribed = true 
                .andWhere("suspended = 0 ")   // suspended = false
                .getRawMany()
                .then((studentsList)=>{
                    let students = studentsList.map(item => item.student_id);
                     // find email ids in messsage
                    let emailsInMsg = this.extractIdsFromMessage(getParams.notification);
                    let finalStudentsList = (emailsInMsg && emailsInMsg.length > 0)? students.concat(emailsInMsg) : students;
                    let message = (finalStudentsList && finalStudentsList.length>0) ? null : MSG.NO_DATA;
                    this.sendResponse(response, 200, message, finalStudentsList);
                    
                }).catch(error => {
                    // console.log(MSG.ORM_ERROR, error);
                    this.sendResponse(response, 500, MSG.ERROR_500);
                });      

            }else{ //invalid request
                this.sendResponse(response, 400 , MSG.INVALID_REQUEST);
            }
        } catch (error) {//something wrong
        this.sendResponse(response, 500, MSG.ERROR_500);
        }
    }
    extractIdsFromMessage(message){
        let matchedItems = (message && message !== "") ? message.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi) : [];
        return matchedItems;
    }

    sendResponse(responseObj, code, Message, response) {

        responseObj.send({
            status: code, 
            message: Message,
            response
        });
    }

}
