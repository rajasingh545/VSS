import {Entity, Column, PrimaryGeneratedColumn} from "typeorm";

@Entity()
class students {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    student_id: string;

    @Column()
    teacher_id: string;

    @Column()
    suspended: boolean;
    
    @Column()
    notification: boolean;

}
export default students;