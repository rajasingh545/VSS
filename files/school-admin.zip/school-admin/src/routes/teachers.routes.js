import studentsContlr from '../controllers/teachers.controller';

const Routes = function(app) {
  
  let students = new studentsContlr();
  // Routes
  app.route('/register').post((request, response)=>{
    students.registerStudents(request, response);

  });

  app.route('/commonstudents').get( async (request, response)=>{
    await students.getStudents(request, response);

  });

  app.route('/suspend').post((request, response)=>{
    students.suspendStudent(request, response);

  });

  app.route('/retrievefornotifications').post((request, response)=>{
    students.retrieveForNotifications(request, response);

  });

}

export default Routes;