import express from "express";
import bodyParser from "body-parser";
import Routes from "./routes/teachers.routes";
import {createConnection} from "typeorm";
//setup express 
const app = express(),
port = process.env.PORT || 3000;

// create typeorm connection
// createConnection();
createConnection().then(async connection => {
  app.use(bodyParser.urlencoded({ extended: true }));
  app.use(bodyParser.json());

  //register routes
  Routes(app); 

  // start express server
  app.listen(port);

  console.log('API server started on: ' + port);

}).catch(error => console.log("TypeORM connection error: ", error));

module.exports = app; // for testing