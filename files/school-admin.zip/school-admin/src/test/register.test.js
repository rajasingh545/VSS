
//Require the dev-dependencies
import chai from "chai";
import chaiHttp from "chai-http";
import server from "../server";
import * as MSG from "../common/messages";

let should = chai.should(); 
chai.use(chaiHttp);

describe('Testing Student Registration', () => {

  describe('/POST ', () => {
      it('To register single students to a specified teacher', (done) => {
        let students = {
            "teacher": "teacherken@gmail.com",
            "students":"studentjon_test1@example.com"
           }
            
        chai.request(server)
            .post('/register')
            .send(students)
            .end((err, res) => {
                res.body.should.have.status(200);
                expect(res.body.message).to.be.equal(MSG.REGISTER_SUCCESS);
              done();
            });
      });
      it('To register one or more students to a specified teacher', (done) => {
        let students = {
            "teacher": "teacherken@gmail.com",
            "students":
                [
                "studentjo_test2@example.com",
                "studenthon_test2@example.com"
                ]
            }
    
        chai.request(server)
            .post('/register')
            .send(students)
            .end((err, res) => {
                //   console.log("response ===", res.body);
                    res.body.should.have.status(200);
                    expect(res.body.message).to.be.equal(MSG.REGISTER_SUCCESS);
                done();
        });
    });
    it('Register duplicate student entry to a specified teacher', (done) => {
        let students = {
          "teacher": "teacherken@gmail.com",
          "students": "studentjon_test1@example.com"
          }
          
        chai.request(server)
          .post('/register')
          .send(students)
          .end((err, res) => {
                res.body.should.have.status(500);
            done();
          });
    });
    it('Invalid request method', (done) => {
        let students = {
          "teacher": "teacherken@gmail.com",
          "students": "studentjon_test@example.com"
          }
          
        chai.request(server)
          .get('/register')
          .send(students)
          .end((err, res) => {
                res.should.have.status(404);
            done();
          });
    });

    it('Invalid request parameter', (done) => {
        let students = {
          "someparam": "teacherken@gmail.com",
          "someparam": "studentjon_test@example.com"
          }
          
        chai.request(server)
          .post('/register')
          .send(students)
          .end((err, res) => {
                res.body.should.have.status(400);
            done();
          });

    });

    });
});
  
