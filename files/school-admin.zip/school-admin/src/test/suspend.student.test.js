
//Require the dev-dependencies
import chai, {expect} from "chai";
import chaiHttp from "chai-http";
import server from "../server";
import * as MSG from "../common/messages";

let should = chai.should(); 
chai.use(chaiHttp);

describe('Testing Student Suspension', () => {

  describe('/POST ', () => {
      it('To suspend a specified student', (done) => {
        let student = {
            "student" : "studentmary@gmail.com"
            }
            
        chai.request(server)
            .post('/suspend')
            .send(student)
            .end((err, res) => {
                res.body.should.have.status(200);
                expect(res.body.message).to.be.equal(MSG.SUSPENDED_SUCCESS);
              done();
            });
      });
      
    it('Invalid request method', (done) => {
        let student = {
          "students": "studentjon_test@example.com"
          }
          
        chai.request(server)
          .get('/suspend')
          .send(student)
          .end((err, res) => {
                res.should.have.status(404);
            done();
          });
    });

    it('Invalid request parameter', (done) => {
        let student = {
          "someparam": "teacherken@gmail.com"
          }
          
        chai.request(server)
          .post('/suspend')
          .send(student)
          .end((err, res) => {
                res.body.should.have.status(400);
            done();
          });

    });

    });
});
  
