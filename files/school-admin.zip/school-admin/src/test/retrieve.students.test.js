
//Require the dev-dependencies
import chai, {expect} from "chai";
import chaiHttp from "chai-http";
import server from "../server";
import * as MSG from "../common/messages";
let should = chai.should();
chai.use(chaiHttp);

describe('Testing Retrieve Students', () => {

  describe('/GET', () => {
      it('To retrieve students common to a given teachers', (done) => {
            
        chai.request(server)
            .get('/commonstudents?teacher=teacherken@gmail.com')
            .end((err, res) => {
                  res.should.have.status(200);
                  expect(res.body.response).to.not.be.undefined;
              done();
            });
      });
      it('To retrieve students common to a given mutiple teachers', (done) => {              
        chai.request(server)
            .get('/commonstudents?teacher=teacherken@gmail.com&teacher=teacher2@gmail.com')
            .end((err, res) => {
                  res.should.have.status(200);
                  expect(res.body.response).to.not.be.undefined;
              done();
        });

      });
      it('No data found', (done) => {
              
        chai.request(server)
            .get('/commonstudents?teacher=somerandomteacherid@gmail.com')
            .end((err, res) => {
                  res.should.have.status(200);
                  expect(res.body.response).to.not.be.undefined;
                  expect(res.body.message).to.be.equal(MSG.NO_DATA);
              done();
            });
      });
      it('Invalid request method', (done) => {
            
        chai.request(server)
            .post('/commonstudents?teacher=teacherken%40example.com')
            .end((err, res) => {
                  res.should.have.status(404);
              done();
            });
      });
      it('Invalid request parameter', (done) => {
                          
        chai.request(server)
            .get('/commonstudents?someparameter=teacherken@example.com')
            .end((err, res) => {
                  res.body.should.have.status(400);
              done();
            });
      });
  

    });
    
});
