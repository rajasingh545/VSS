
//Require the dev-dependencies
import chai, {expect} from "chai";
import chaiHttp from "chai-http";
import server from "../server";
import * as MSG from "../common/messages";
let should = chai.should();
chai.use(chaiHttp);

describe('Testing Retrieve Notifications', () => {

  describe('/POST ', () => {
      it('Retrieve students who can receive a given notification and mentioned in notification text', (done) => {
            
        let students = {
            "teacher": "teacherken@example.com",
            "notification": "Hello students! @studentagnes@example.com @studentmiche@example.com"
            }
            
          chai.request(server)
            .post('/retrievefornotifications')
            .send(students)
            .end((err, res) => {
                  res.body.should.have.status(200);
                  expect(res.body.response).to.have.members(["studentagnes@example.com", "studentmiche@example.com"]);
              done();
            });
      });
      it('Retrieve students who can receive a given notification for respective teacher', (done) => {
            
        let students = {
            "teacher": "teacherken@example.com",
            "notification": "Hello students!"
            }
            
          chai.request(server)
            .post('/retrievefornotifications')
            .send(students)
            .end((err, res) => {
                  res.body.should.have.status(200);
                  expect(res.body.response).to.not.be.undefined;
              done();
            });
      });
        

    });
    
});
